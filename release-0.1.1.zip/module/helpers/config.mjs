export const ORESYSTEM = {};

// Define constants here, such as:
ORESYSTEM.foobar = {
  'bas': 'ORESYSTEM.bas',
  'bar': 'ORESYSTEM.bar'
};