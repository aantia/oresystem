A very basic system for playing ORE games. I run a hybrid of Reign and Wild Talents, so if anything is weird blame that. If anything is ugly or just bad UX, blame my general incompetence in the sphere of web development.

TODO: Make system settings to switch elements on and off (e.g. Powers tab) and rename elements (e.g. Passions).
      Prettify the sheet; this default css is horribly ugly.
      Add support for other ORE systems, e.g. A

Credits:
itamarcu, for the dice roller https://github.com/itamarcu/one-roll-engine
The team behind the Vampire 5th edition sheet for the health boxes https://github.com/Rayji96/foundry-V5
Matt Smith @Asacolips for the Boilerplate template https://gitlab.com/asacolips-projects/foundry-mods/boilerplate
aantia for the rest of the system
Greg Stolze for the ORE itself.



License:
MIT, for anything I wrote. Check Mr Stolze's website for information on use of the ORE, and the links above to the other credits' sources for their respective licenses.
